plutus
======

Plutus Microfinance Management System

Version 1 - July 23, 2013

